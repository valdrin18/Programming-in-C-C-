#include <stdio.h>
int main() {
    int result;
    result = (2 + 7) * 9 / 3;
    printf("The result is %d\n",result);
    return 0;
}
//we had to call variable result at print command
