/* CH-230-A
  A1.p6 Print char (lanuage-C)
 Valdrin Smakaj
Vsmakaj@jacobs-university.de
*/

#include <stdio.h>
#include <stdlib.h>

int main()
{
    char c='F';
    printf("Value of C is %c and the ASCII value of it is %d\n",c+3,c+3);
    return 0;
}
