#include <stdio.h>
int main() {
    double result;
    result = (float)(3 + 1) / 5;
    printf("The value of 4/5 is %lf\n", result);
return 0;
}
//used float befoer calculation of result or, we could even make result as float and %f at print
