/* CH-230-A
  A1.p5 Data_types (lanuage-C)
 Valdrin Smakaj
Vsmakaj@jacobs-university.de
*/

#include <stdio.h>
#include <stdlib.h>

int main()
{
    int x=2138;
    float y=-52.358925;
    char z='G';
    double u=61.295339687;
    printf("x=%9d\n",x);
    printf("y=%11.5f\n",y);
    printf("z=%c\n",z);
    printf("u=%.7lf\n",u);
    return 0;
}
